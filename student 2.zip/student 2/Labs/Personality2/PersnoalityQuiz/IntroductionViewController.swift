//
//  ViewController.swift
//  PersnoalityQuiz
//
//  Created by Student on 05/03/24.
//

import UIKit

class IntroductionViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

