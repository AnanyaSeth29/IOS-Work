/*:
## Exercise - Constant or Variable?
 
 Imagine you're creating a simple photo sharing app. You want to keep track of the following metrics for each post:
- Number of likes: the number of likes that a photo has received
- Number of comments: the number of comments other users have left on the photo
- Year created: The year the post was created
- Month created: The month the post was created represented by a number between 1 and 12
- Day created: The day of the month the post was created
 
 For each of the metrics above, declare either a constant or a variable and assign it a value corresponding to a hypothetical post. Be sure to use proper naming conventions.
 */
struct Post{
    var likeCounter : Int
    var commentCounter : Int
    let yearCreated : Int
    let monthCreated : Int
    let dayCreated : Int
    
    func share(){
        print("Likes on this post : \(likeCounter)")
        print("Comments on this post : \(commentCounter)")
        print("This post was created in year : \(yearCreated)")
        print("This post was created in month : \(monthCreated)")
        print("This post was created in year : \(dayCreated)")
    }
}

/*:
[Previous](@previous)  |  page 5 of 10  |  [Next: App Exercise - Fitness Tracker: Constant or Variable?](@next)
 */
